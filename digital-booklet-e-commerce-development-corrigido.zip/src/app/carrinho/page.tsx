"use client";

/**
 * Página do Carrinho
 *
 * O carrinho serve como lista de interesse. Cada item possui botões
 * que redirecionam para o link de pagamento externo (Mercado Pago ou PagBank).
 * Não existe checkout interno, ID de pedido ou transação gerada aqui.
 */

import { useState } from "react";
import Link from "next/link";
import { Trash2, Plus, Minus, ShoppingCart, Tag } from "lucide-react";
import { useCartStore, useCouponStore } from "@/lib/store";
import { formatPrice } from "@/lib/utils";
import ProductCover from "@/components/ProductCover";

// Cupons de demonstração — desconto aplicado apenas visualmente,
// o preço final é praticado no link externo de pagamento.
const VALID_COUPONS: Record<string, { type: "percentage" | "fixed"; value: number }> = {
  KLEBER10:   { type: "percentage", value: 10 },
  KLEBER20:   { type: "percentage", value: 20 },
  DESCONTO15: { type: "fixed",      value: 15 },
};

export default function CartPage() {
  const { items, removeItem, updateQuantity, total, clearCart } = useCartStore();
  const { code, discount, type, setCode, setDiscount, clear: clearCoupon } = useCouponStore();

  const [couponInput,   setCouponInput]   = useState(code);
  const [couponError,   setCouponError]   = useState("");
  const [couponSuccess, setCouponSuccess] = useState("");

  const subtotal      = total();
  const discountAmt   = type === "percentage" ? subtotal * (discount / 100) : discount;
  const finalTotal    = Math.max(subtotal - discountAmt, 0);

  const applyCoupon = () => {
    const c = VALID_COUPONS[couponInput.toUpperCase()];
    if (!couponInput) { setCouponError("Digite um cupom"); return; }
    if (!c) { setCouponError("Cupom inválido"); setCouponSuccess(""); return; }
    setCode(couponInput.toUpperCase());
    setDiscount(c.value, c.type);
    setCouponSuccess(
      `Cupom aplicado! ${c.type === "percentage" ? `${c.value}% de desconto` : `${formatPrice(c.value)} de desconto`}`
    );
    setCouponError("");
  };

  // ── Empty state ──────────────────────────────────────────────────────────
  if (items.length === 0) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-20 text-center">
        <div className="text-7xl mb-4">🛒</div>
        <h1 className="text-2xl font-black text-gray-900 dark:text-white mb-2">Carrinho vazio</h1>
        <p className="text-gray-500 dark:text-gray-400 mb-6">
          Adicione apostilas ao carrinho ou compre diretamente em cada produto.
        </p>
        <Link
          href="/apostilas"
          className="bg-blue-600 text-white px-8 py-3 rounded-2xl font-semibold hover:bg-blue-700 transition-colors"
        >
          Ver Apostilas
        </Link>
      </div>
    );
  }

  // ── Cart ─────────────────────────────────────────────────────────────────
  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-black text-gray-900 dark:text-white mb-6 flex items-center gap-3">
        <ShoppingCart size={32} />
        Carrinho ({items.length} {items.length === 1 ? "item" : "itens"})
      </h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">

        {/* ── Item list ──────────────────────────────────────────────────── */}
        <div className="lg:col-span-2 space-y-4">
          {items.map(({ product, quantity }) => (
            <div
              key={product.id}
              className="bg-white dark:bg-gray-900 rounded-2xl p-4 shadow border border-gray-100 dark:border-gray-800"
            >
              <div className="flex gap-4 items-start">
                {/* Cover */}
                <ProductCover
                  coverImage={product.coverImage}
                  title={product.title}
                  size="small"
                  className="flex-shrink-0"
                />

                {/* Details */}
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-gray-900 dark:text-white text-sm line-clamp-2 mb-1">
                    {product.title}
                  </h3>
                  <p className="text-xs text-gray-400 mb-2">📄 PDF • {product.pages} páginas</p>

                  {/* Price */}
                  <div className="text-lg font-black text-green-600 dark:text-green-400 mb-3">
                    {formatPrice(product.price)}
                    {product.originalPrice && (
                      <span className="text-xs text-gray-400 line-through ml-2">
                        {formatPrice(product.originalPrice)}
                      </span>
                    )}
                  </div>

                  {/* Qty control */}
                  <div className="flex items-center gap-3 mb-3">
                    <div className="flex items-center border border-gray-200 dark:border-gray-700 rounded-xl overflow-hidden">
                      <button
                        onClick={() => updateQuantity(product.id, Math.max(1, quantity - 1))}
                        className="p-2 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors text-gray-600 dark:text-gray-400"
                      >
                        <Minus size={13} />
                      </button>
                      <span className="w-8 text-center text-sm font-semibold text-gray-900 dark:text-white">
                        {quantity}
                      </span>
                      <button
                        onClick={() => updateQuantity(product.id, quantity + 1)}
                        className="p-2 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors text-gray-600 dark:text-gray-400"
                      >
                        <Plus size={13} />
                      </button>
                    </div>
                    <button
                      onClick={() => removeItem(product.id)}
                      className="text-red-400 hover:text-red-600 transition-colors flex items-center gap-1 text-xs"
                    >
                      <Trash2 size={14} /> Remover
                    </button>
                  </div>

                  {/* ── Per-item payment buttons ── */}
                  <div className="grid grid-cols-2 gap-2">
                    <Link
                      href={product.mercadoPagoLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-center gap-1.5 bg-[#009ee3] hover:bg-[#0087c4]
                        text-white text-xs font-bold py-2.5 rounded-xl transition-colors"
                    >
                      💳 Mercado Pago
                    </Link>
                    <Link
                      href={product.pagBankLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-center gap-1.5 bg-[#f4b000] hover:bg-[#dba000]
                        text-gray-900 text-xs font-bold py-2.5 rounded-xl transition-colors"
                    >
                      🏦 PagBank
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          ))}

          <button
            onClick={clearCart}
            className="text-sm text-red-400 hover:text-red-600 flex items-center gap-1 mt-1 transition-colors"
          >
            <Trash2 size={14} /> Limpar carrinho
          </button>
        </div>

        {/* ── Order summary ───────────────────────────────────────────────── */}
        <div className="lg:col-span-1">
          <div className="bg-white dark:bg-gray-900 rounded-2xl p-6 shadow border border-gray-100 dark:border-gray-800 sticky top-24 space-y-5">
            <h2 className="text-lg font-bold text-gray-900 dark:text-white">Resumo</h2>

            {/* Coupon */}
            <div>
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300 flex items-center gap-2 mb-2">
                <Tag size={14} /> Cupom de desconto
              </label>
              <div className="flex gap-2">
                <input
                  value={couponInput}
                  onChange={(e) => setCouponInput(e.target.value)}
                  placeholder="KLEBER10"
                  className="flex-1 border border-gray-300 dark:border-gray-700 dark:bg-gray-800 dark:text-white
                    rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <button
                  onClick={applyCoupon}
                  className="bg-blue-600 text-white px-3 py-2 rounded-xl text-sm font-semibold hover:bg-blue-700 transition-colors"
                >
                  OK
                </button>
              </div>
              {code && (
                <button
                  onClick={() => { clearCoupon(); setCouponInput(""); setCouponSuccess(""); }}
                  className="text-red-400 text-xs hover:text-red-600 mt-1"
                >
                  Remover cupom
                </button>
              )}
              {couponError   && <p className="text-red-500 text-xs mt-1">{couponError}</p>}
              {couponSuccess && <p className="text-green-500 text-xs mt-1">✅ {couponSuccess}</p>}
              <p className="text-xs text-gray-400 mt-1">Ex: KLEBER10 · KLEBER20 · DESCONTO15</p>
            </div>

            {/* Totals */}
            <div className="space-y-2 border-t border-gray-100 dark:border-gray-800 pt-4 text-sm">
              <div className="flex justify-between text-gray-600 dark:text-gray-400">
                <span>Subtotal</span>
                <span>{formatPrice(subtotal)}</span>
              </div>
              {discountAmt > 0 && (
                <div className="flex justify-between text-green-600">
                  <span>Desconto ({code})</span>
                  <span>-{formatPrice(discountAmt)}</span>
                </div>
              )}
              <div className="flex justify-between text-gray-600 dark:text-gray-400">
                <span>Entrega (digital)</span>
                <span className="text-green-600 font-medium">Grátis</span>
              </div>
              <div className="flex justify-between text-xl font-black text-gray-900 dark:text-white border-t border-gray-100 dark:border-gray-800 pt-3">
                <span>Total estimado</span>
                <span className="text-green-600 dark:text-green-400">{formatPrice(finalTotal)}</span>
              </div>
            </div>

            {/* Note */}
            <p className="text-xs text-gray-400 dark:text-gray-500 text-center leading-relaxed">
              Clique em <strong>Mercado Pago</strong> ou <strong>PagBank</strong> ao lado de cada produto
              para efetuar o pagamento de forma segura e direta.
            </p>

            {/* Continue shopping */}
            <Link
              href="/apostilas"
              className="w-full flex items-center justify-center text-sm text-blue-600 dark:text-blue-400 hover:underline"
            >
              ← Continuar comprando
            </Link>

            {/* Payment badges */}
            <div className="flex items-center justify-center gap-3 text-xs text-gray-400 pt-1">
              <span>🔒 Seguro</span>
              <span>💳 Cartão</span>
              <span>📱 PIX</span>
              <span>🏦 Boleto</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
