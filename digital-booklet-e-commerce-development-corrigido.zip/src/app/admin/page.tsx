"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { useAuthStore } from "@/lib/store";
import { PRODUCTS, CATEGORIES, formatPrice } from "@/lib/data";
import { BarChart3, Package, Users, ShoppingBag, TrendingUp, Star, Tag, Settings, Home } from "lucide-react";
import { useRouter } from "next/navigation";

type Stats = { users: number; orders: number; revenue: number; products: number };

export default function AdminPage() {
  const { user } = useAuthStore();
  const router = useRouter();
  const [stats, setStats] = useState<Stats>({ users: 0, orders: 0, revenue: 0, products: 50 });
  const [activeTab, setActiveTab] = useState("dashboard");
  const [seeding, setSeeding] = useState(false);
  const [seedMsg, setSeedMsg] = useState("");

  useEffect(() => {
    if (!user || user.role !== "admin") { router.push("/login"); return; }
    fetch("/api/admin/stats").then((r) => r.json()).then(setStats).catch(console.error);
  }, [user, router]);

  const handleSeed = async () => {
    setSeeding(true);
    const res = await fetch("/api/admin/seed", { method: "POST" });
    const data = await res.json();
    setSeedMsg(data.message || data.error || "Concluído");
    setSeeding(false);
    fetch("/api/admin/stats").then((r) => r.json()).then(setStats).catch(console.error);
  };

  if (!user || user.role !== "admin") {
    return <div className="flex items-center justify-center min-h-screen"><div className="text-gray-500">Verificando permissões...</div></div>;
  }

  const TABS = [
    { id: "dashboard", icon: BarChart3, label: "Dashboard" },
    { id: "products", icon: Package, label: "Produtos" },
    { id: "orders", icon: ShoppingBag, label: "Pedidos" },
    { id: "users", icon: Users, label: "Clientes" },
    { id: "coupons", icon: Tag, label: "Cupons" },
    { id: "reports", icon: TrendingUp, label: "Relatórios" },
    { id: "settings", icon: Settings, label: "Configurações" },
  ];

  const topProducts = [...PRODUCTS].sort((a, b) => b.salesCount - a.salesCount).slice(0, 10);

  return (
    <div className="flex min-h-screen bg-gray-50 dark:bg-gray-950">
      {/* Sidebar */}
      <aside className="w-16 lg:w-64 bg-white dark:bg-gray-900 border-r border-gray-100 dark:border-gray-800 flex flex-col py-4 shadow-sm">
        <div className="px-4 mb-6 hidden lg:block">
          <div className="font-black text-blue-700 dark:text-blue-400 text-lg">🏪 Painel Admin</div>
          <div className="text-xs text-gray-400">Olá, {user.name.split(" ")[0]}!</div>
        </div>

        <nav className="flex-1 space-y-1 px-2">
          {TABS.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors ${
                activeTab === tab.id
                  ? "bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400"
                  : "text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-800"
              }`}
            >
              <tab.icon size={18} className="flex-shrink-0" />
              <span className="hidden lg:block">{tab.label}</span>
            </button>
          ))}
        </nav>

        <div className="px-2 mt-4 border-t border-gray-100 dark:border-gray-800 pt-4">
          <Link href="/" className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
            <Home size={18} />
            <span className="hidden lg:block">Ir para Loja</span>
          </Link>
        </div>
      </aside>

      {/* Main */}
      <main className="flex-1 overflow-auto p-6">
        {/* Dashboard */}
        {activeTab === "dashboard" && (
          <div>
            <h1 className="text-2xl font-black text-gray-900 dark:text-white mb-6">📊 Dashboard</h1>

            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              {[
                { label: "Apostilas", value: stats.products, icon: "📚", color: "blue", sub: "no catálogo" },
                { label: "Vendas Estimadas", value: PRODUCTS.reduce((s, p) => s + p.salesCount, 0).toLocaleString("pt-BR"), icon: "🛒", color: "green", sub: "unidades vendidas" },
                { label: "Clientes", value: stats.users, icon: "👥", color: "purple", sub: "cadastrados" },
                { label: "Avaliação Média", value: "4.9★", icon: "⭐", color: "amber", sub: "dos produtos" },
              ].map((s) => (
                <div key={s.label} className="bg-white dark:bg-gray-900 rounded-2xl p-5 shadow border border-gray-100 dark:border-gray-800">
                  <div className="flex items-center justify-between mb-2">
                    <div className="text-2xl">{s.icon}</div>
                  </div>
                  <div className="text-2xl font-black text-gray-900 dark:text-white">{s.value}</div>
                  <div className="text-sm font-medium text-gray-600 dark:text-gray-400">{s.label}</div>
                  <div className="text-xs text-gray-400 mt-1">{s.sub}</div>
                </div>
              ))}
            </div>

            {/* Top products */}
            <div className="bg-white dark:bg-gray-900 rounded-2xl shadow border border-gray-100 dark:border-gray-800 p-6">
              <h2 className="text-lg font-bold text-gray-900 dark:text-white mb-4">🔥 Top 10 Mais Vendidos</h2>
              <div className="space-y-3">
                {topProducts.map((p, i) => (
                  <div key={p.id} className="flex items-center gap-3">
                    <span className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-black ${i < 3 ? "bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400" : "bg-gray-100 dark:bg-gray-800 text-gray-500"}`}>
                      {i + 1}
                    </span>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium text-gray-900 dark:text-white truncate">{p.title}</div>
                      <div className="flex items-center gap-2 text-xs text-gray-400">
                        <span>⭐ {p.rating}</span>
                        <span>•</span>
                        <span>{p.reviewCount} avaliações</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-black text-green-600 dark:text-green-400">{formatPrice(p.price)}</div>
                      <div className="text-xs text-gray-400">{p.salesCount} vendas</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Seed button */}
            <div className="mt-6 bg-white dark:bg-gray-900 rounded-2xl p-4 border border-gray-100 dark:border-gray-800 shadow">
              <h3 className="font-bold text-gray-900 dark:text-white mb-2">⚙️ Configuração Inicial</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400 mb-3">Crie usuários demo, categorias e cupons no banco de dados.</p>
              <button
                onClick={handleSeed}
                disabled={seeding}
                className="bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white px-4 py-2 rounded-xl text-sm font-semibold transition-colors"
              >
                {seeding ? "Criando..." : "🌱 Criar Dados Iniciais"}
              </button>
              {seedMsg && <p className="text-green-600 dark:text-green-400 text-sm mt-2">✅ {seedMsg}</p>}
            </div>
          </div>
        )}

        {/* Products */}
        {activeTab === "products" && (
          <div>
            <div className="flex items-center justify-between mb-6">
              <h1 className="text-2xl font-black text-gray-900 dark:text-white">📚 Produtos ({PRODUCTS.length})</h1>
              <button className="bg-blue-600 text-white px-4 py-2 rounded-xl text-sm font-semibold hover:bg-blue-700 transition-colors">
                + Adicionar Produto
              </button>
            </div>
            {/* ── Info: how payment links work ── */}
            <div className="mb-4 p-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-2xl text-sm text-blue-800 dark:text-blue-300">
              <strong>💡 Pagamento por link externo</strong> — cada apostila possui um link do Mercado Pago e
              um link do PagBank. Nenhum checkout interno é criado. Para alterar os links, edite o arquivo{" "}
              <code className="bg-blue-100 dark:bg-blue-900 px-1 rounded">src/lib/data.ts</code>.
            </div>

            <div className="bg-white dark:bg-gray-900 rounded-2xl shadow border border-gray-100 dark:border-gray-800 overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50 dark:bg-gray-800">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">
                      Produto / Nome
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">
                      Preço
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">
                      Link Mercado Pago
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">
                      Link PagBank
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">
                      Status
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50 dark:divide-gray-800">
                  {PRODUCTS.map((p) => (
                    <tr key={p.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors">
                      {/* Nome */}
                      <td className="px-4 py-3 min-w-[180px]">
                        <div className="font-medium text-gray-900 dark:text-white text-xs line-clamp-2 max-w-[220px]">
                          {p.title}
                        </div>
                        <div className="text-xs text-gray-400 mt-0.5">{p.pages} págs • {p.format}</div>
                      </td>

                      {/* Preço */}
                      <td className="px-4 py-3 whitespace-nowrap">
                        <div className="font-black text-green-600 dark:text-green-400 text-sm">
                          {formatPrice(p.price)}
                        </div>
                        {p.originalPrice && (
                          <div className="text-xs text-gray-400 line-through">{formatPrice(p.originalPrice)}</div>
                        )}
                      </td>

                      {/* Link MP */}
                      <td className="px-4 py-3 min-w-[180px]">
                        <a
                          href={p.mercadoPagoLink}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1.5 bg-[#009ee3] hover:bg-[#0087c4] text-white
                            text-xs font-bold px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap"
                        >
                          💳 Mercado Pago ↗
                        </a>
                        <div className="text-xs text-gray-400 mt-1 max-w-[160px] truncate" title={p.mercadoPagoLink}>
                          {p.mercadoPagoLink}
                        </div>
                      </td>

                      {/* Link PagBank */}
                      <td className="px-4 py-3 min-w-[160px]">
                        <a
                          href={p.pagBankLink}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1.5 bg-[#f4b000] hover:bg-[#dba000] text-gray-900
                            text-xs font-bold px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap"
                        >
                          🏦 PagBank ↗
                        </a>
                        <div className="text-xs text-gray-400 mt-1 max-w-[140px] truncate" title={p.pagBankLink}>
                          {p.pagBankLink}
                        </div>
                      </td>

                      {/* Status */}
                      <td className="px-4 py-3 whitespace-nowrap">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          p.featured
                            ? "bg-amber-50 dark:bg-amber-900/20 text-amber-700 dark:text-amber-400"
                            : "bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-400"
                        }`}>
                          {p.featured ? "⭐ Destaque" : "✓ Ativo"}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Coupons */}
        {activeTab === "coupons" && (
          <div>
            <h1 className="text-2xl font-black text-gray-900 dark:text-white mb-6">🎟️ Cupons de Desconto</h1>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
              {[
                { code: "KLEBER10", type: "10% OFF", desc: "Desconto de 10% em qualquer produto", used: 23, max: 100 },
                { code: "KLEBER20", type: "20% OFF", desc: "Desconto de 20% acima de R$50", used: 8, max: 50 },
                { code: "DESCONTO15", type: "R$15 OFF", desc: "R$15 off acima de R$30", used: 45, max: 200 },
              ].map((c) => (
                <div key={c.code} className="bg-white dark:bg-gray-900 rounded-2xl p-5 shadow border border-dashed border-blue-300 dark:border-blue-800">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-black text-xl text-blue-700 dark:text-blue-400">{c.code}</span>
                    <span className="bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-400 text-xs px-2 py-1 rounded-full font-bold">{c.type}</span>
                  </div>
                  <p className="text-sm text-gray-500 dark:text-gray-400 mb-3">{c.desc}</p>
                  <div className="flex items-center justify-between text-xs text-gray-400">
                    <span>{c.used} usos</span>
                    <span>máx. {c.max}</span>
                  </div>
                  <div className="mt-2 bg-gray-100 dark:bg-gray-800 rounded-full h-1.5">
                    <div className="bg-blue-500 h-1.5 rounded-full" style={{ width: `${(c.used / c.max) * 100}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Reports */}
        {activeTab === "reports" && (
          <div>
            <h1 className="text-2xl font-black text-gray-900 dark:text-white mb-6">📈 Relatórios</h1>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="bg-white dark:bg-gray-900 rounded-2xl p-6 shadow border border-gray-100 dark:border-gray-800">
                <h2 className="font-bold text-gray-900 dark:text-white mb-4">💰 Receita por Categoria</h2>
                <div className="space-y-3">
                  {CATEGORIES.map((cat) => {
                    const catProducts = PRODUCTS.filter((p) => p.categoryId === cat.id);
                    const revenue = catProducts.reduce((s, p) => s + p.price * p.salesCount, 0);
                    const total = PRODUCTS.reduce((s, p) => s + p.price * p.salesCount, 0);
                    const pct = Math.round((revenue / total) * 100);
                    return (
                      <div key={cat.id}>
                        <div className="flex items-center justify-between text-sm mb-1">
                          <span className="text-gray-700 dark:text-gray-300">{cat.icon} {cat.name}</span>
                          <span className="font-bold text-gray-900 dark:text-white">{pct}%</span>
                        </div>
                        <div className="bg-gray-100 dark:bg-gray-800 rounded-full h-2">
                          <div className="bg-blue-500 h-2 rounded-full transition-all" style={{ width: `${pct}%` }} />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="bg-white dark:bg-gray-900 rounded-2xl p-6 shadow border border-gray-100 dark:border-gray-800">
                <h2 className="font-bold text-gray-900 dark:text-white mb-4">⭐ Avaliações Médias</h2>
                <div className="space-y-3">
                  {CATEGORIES.map((cat) => {
                    const catProducts = PRODUCTS.filter((p) => p.categoryId === cat.id);
                    const avg = catProducts.reduce((s, p) => s + p.rating, 0) / (catProducts.length || 1);
                    return (
                      <div key={cat.id} className="flex items-center gap-3">
                        <span className="text-lg">{cat.icon}</span>
                        <div className="flex-1">
                          <div className="text-sm text-gray-700 dark:text-gray-300 mb-0.5">{cat.name}</div>
                          <div className="flex">
                            {[1,2,3,4,5].map((s) => (
                              <span key={s} className={s <= Math.round(avg) ? "text-yellow-400 text-xs" : "text-gray-200 text-xs"}>★</span>
                            ))}
                          </div>
                        </div>
                        <span className="text-sm font-bold text-amber-500">{avg.toFixed(1)}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Other tabs */}
        {(activeTab === "orders" || activeTab === "users" || activeTab === "settings") && (
          <div className="text-center py-20">
            <div className="text-5xl mb-4">🚧</div>
            <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Em desenvolvimento</h2>
            <p className="text-gray-500">Esta seção será integrada com o banco de dados em breve.</p>
          </div>
        )}
      </main>
    </div>
  );
}
