"use client";

/**
 * Esta loja não possui checkout interno.
 * O pagamento é feito diretamente nos links externos de cada produto:
 *   • Mercado Pago
 *   • PagBank
 *
 * Este arquivo existe apenas para redirecionar o cliente ao carrinho,
 * onde os botões de pagamento externo estão disponíveis.
 */

import { useEffect } from "react";
import { useRouter } from "next/navigation";

export default function CheckoutRedirectPage() {
  const router = useRouter();

  useEffect(() => {
    router.replace("/carrinho");
  }, [router]);

  return (
    <div className="flex flex-col items-center justify-center min-h-96 gap-4 text-gray-500 dark:text-gray-400">
      <div className="text-5xl animate-bounce">🛒</div>
      <p className="text-sm">Redirecionando para o carrinho…</p>
    </div>
  );
}
