import { NextResponse } from "next/server";
import { db } from "@/db";
import { users, categories, coupons } from "@/db/schema";
import { eq } from "drizzle-orm";
import bcrypt from "bcryptjs";

export async function POST() {
  try {
    // Seed admin user
    const adminEmail = "admin@kleberstore.com";
    const [existingAdmin] = await db.select().from(users).where(eq(users.email, adminEmail));
    if (!existingAdmin) {
      await db.insert(users).values({
        name: "Kleber Admin",
        email: adminEmail,
        password: await bcrypt.hash("admin123", 10),
        role: "admin",
      });
    }

    // Seed customer
    const customerEmail = "cliente@teste.com";
    const [existingCustomer] = await db.select().from(users).where(eq(users.email, customerEmail));
    if (!existingCustomer) {
      await db.insert(users).values({
        name: "Cliente Demo",
        email: customerEmail,
        password: await bcrypt.hash("cliente123", 10),
        role: "customer",
      });
    }

    // Seed categories
    const cats = [
      { name: "Normas Regulamentadoras", slug: "normas-regulamentadoras", icon: "📋", description: "Apostilas completas sobre NRs" },
      { name: "Primeiros Socorros", slug: "primeiros-socorros", icon: "🏥", description: "APH e emergências médicas" },
      { name: "Resgate e Salvamento", slug: "resgate-salvamento", icon: "🚒", description: "Técnicas avançadas de resgate" },
      { name: "Prevenção de Incêndios", slug: "prevencao-incendios", icon: "🔥", description: "Combate e prevenção" },
      { name: "Equipamentos de Proteção", slug: "equipamentos-protecao", icon: "🦺", description: "EPI e EPC" },
    ];
    for (const cat of cats) {
      const [existing] = await db.select().from(categories).where(eq(categories.slug, cat.slug));
      if (!existing) await db.insert(categories).values(cat);
    }

    // Seed coupons
    const couponData = [
      { code: "KLEBER10", discountType: "percentage", discountValue: "10", minPurchase: "0", maxUses: 100 },
      { code: "KLEBER20", discountType: "percentage", discountValue: "20", minPurchase: "50", maxUses: 50 },
      { code: "DESCONTO15", discountType: "fixed", discountValue: "15", minPurchase: "30", maxUses: 200 },
    ];
    for (const c of couponData) {
      const [existing] = await db.select().from(coupons).where(eq(coupons.code, c.code));
      if (!existing) await db.insert(coupons).values(c);
    }

    return NextResponse.json({ success: true, message: "Dados iniciais criados com sucesso!" });
  } catch (error) {
    console.error("Seed error:", error);
    return NextResponse.json({ error: "Erro ao criar dados iniciais" }, { status: 500 });
  }
}
