import { NextResponse } from "next/server";
import { db } from "@/db";
import { users, orders } from "@/db/schema";
import { sql } from "drizzle-orm";

export async function GET() {
  try {
    const [userCount] = await db.select({ count: sql<number>`count(*)` }).from(users);
    const [orderCount] = await db.select({ count: sql<number>`count(*)` }).from(orders);
    const [revenue] = await db.select({ total: sql<number>`coalesce(sum(total::numeric), 0)` }).from(orders);

    return NextResponse.json({
      users: Number(userCount?.count ?? 0),
      orders: Number(orderCount?.count ?? 0),
      revenue: Number(revenue?.total ?? 0),
      products: 50,
    });
  } catch (error) {
    console.error("Stats error:", error);
    return NextResponse.json({ users: 0, orders: 0, revenue: 0, products: 50 });
  }
}
