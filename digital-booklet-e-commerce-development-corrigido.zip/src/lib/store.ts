"use client";
import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { Product } from "./data";

export type CartItem = {
  product: Product;
  quantity: number;
};

type CartStore = {
  items: CartItem[];
  addItem: (product: Product) => void;
  removeItem: (productId: number) => void;
  updateQuantity: (productId: number, quantity: number) => void;
  clearCart: () => void;
  total: () => number;
  count: () => number;
};

export const useCartStore = create<CartStore>()(
  persist(
    (set, get) => ({
      items: [],
      addItem: (product) => {
        const existing = get().items.find((i) => i.product.id === product.id);
        if (existing) {
          set((s) => ({
            items: s.items.map((i) =>
              i.product.id === product.id ? { ...i, quantity: i.quantity + 1 } : i
            ),
          }));
        } else {
          set((s) => ({ items: [...s.items, { product, quantity: 1 }] }));
        }
      },
      removeItem: (productId) =>
        set((s) => ({ items: s.items.filter((i) => i.product.id !== productId) })),
      updateQuantity: (productId, quantity) =>
        set((s) => ({
          items: s.items.map((i) =>
            i.product.id === productId ? { ...i, quantity } : i
          ),
        })),
      clearCart: () => set({ items: [] }),
      total: () => get().items.reduce((sum, i) => sum + i.product.price * i.quantity, 0),
      count: () => get().items.reduce((sum, i) => sum + i.quantity, 0),
    }),
    { name: "kleber-cart" }
  )
);

type FavoritesStore = {
  ids: number[];
  toggle: (productId: number) => void;
  isFavorite: (productId: number) => boolean;
};

export const useFavoritesStore = create<FavoritesStore>()(
  persist(
    (set, get) => ({
      ids: [],
      toggle: (productId) => {
        const ids = get().ids;
        set({ ids: ids.includes(productId) ? ids.filter((i) => i !== productId) : [...ids, productId] });
      },
      isFavorite: (productId) => get().ids.includes(productId),
    }),
    { name: "kleber-favorites" }
  )
);

export type AuthUser = {
  id: number;
  name: string;
  email: string;
  role: string;
  purchasedIds: number[];
};

type AuthStore = {
  user: AuthUser | null;
  setUser: (user: AuthUser | null) => void;
  logout: () => void;
};

export const useAuthStore = create<AuthStore>()(
  persist(
    (set) => ({
      user: null,
      setUser: (user) => set({ user }),
      logout: () => set({ user: null }),
    }),
    { name: "kleber-auth" }
  )
);

type CouponStore = {
  code: string;
  discount: number;
  type: "percentage" | "fixed";
  setCode: (code: string) => void;
  setDiscount: (discount: number, type: "percentage" | "fixed") => void;
  clear: () => void;
};

export const useCouponStore = create<CouponStore>()((set) => ({
  code: "",
  discount: 0,
  type: "percentage",
  setCode: (code) => set({ code }),
  setDiscount: (discount, type) => set({ discount, type }),
  clear: () => set({ code: "", discount: 0, type: "percentage" }),
}));
